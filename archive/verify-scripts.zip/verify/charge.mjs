// 改善案B: アリが自陣で黒マスを踏むたびに「積載量」を+1(黒は白に反転=消費される)。
// 敵陣到達時の積載量をダメージにする。トークン投資が直接ダメージに変換されるか検証。
const W=40,H=20,BOUND=20;
const DIRS=[[0,-1],[1,0],[0,1],[-1,0]];
const rnd=n=>Math.floor(Math.random()*n);
const st=a=>{if(!a.length)return'n/a';const s=[...a].sort((x,y)=>x-y);const q=p=>s[Math.min(s.length-1,Math.floor(s.length*p))];
  return `median=${q(.5)} p75=${q(.75)} p95=${q(.95)} max=${s[s.length-1]} mean=${(a.reduce((x,y)=>x+y,0)/a.length).toFixed(2)}`;};

function trial(nBlack, trials=30000, buffer=0){
  let arrived=0; const dmg=[], all=[];
  for(let t=0;t<trials;t++){
    const b=new Uint8Array(W*H); const maxX=BOUND-buffer;
    for(let k=0;k<nBlack;k++) b[rnd(H)*W+rnd(maxX)]=1;
    let ax=rnd(maxX),ay=rnd(H),dir=rnd(4),steps=0,out=null,charge=0;
    while(steps<200000){
      const i=ay*W+ax;
      if(b[i]===0){b[i]=1;dir=(dir+1)&3;}else{b[i]=0;dir=(dir+3)&3;charge++;}
      ax+=DIRS[dir][0];ay+=DIRS[dir][1];steps++;
      if(ax<0||ay<0||ax>=W||ay>=H){out='off';break;}
      if(ax>=BOUND){out='arr';break;}
    }
    all.push(out==='arr'?charge:0);
    if(out==='arr'){arrived++;dmg.push(charge);}
  }
  return {nBlack, 到達率:(arrived/trials*100).toFixed(1)+'%', 到達時ダメージ:st(dmg), '1発あたり期待値':(all.reduce((x,y)=>x+y,0)/trials).toFixed(2)};
}
console.log('=== 改善案B: 踏んだ黒マスを「積載」してダメージにする(ランダム配置での下限性能) ===');
for(const n of [0,10,25,50,100]) console.log(trial(n));
