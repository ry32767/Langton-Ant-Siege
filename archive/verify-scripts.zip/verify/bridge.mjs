// 改善案A の成立性検証:
// 境界から3列は配置禁止。自陣に連結した黒の塊(N個)を置き、アリを配置。
// アリが自力で「塊 -> 境界」の黒い橋を掘り、到達マスから連結した黒マス数がダメージになるか?
const W=40,H=20,BOUND=20,BUFFER=3, MAXX=BOUND-BUFFER; // 配置可能 x: 0..16
const DIRS=[[0,-1],[1,0],[0,1],[-1,0]];
const rnd=n=>Math.floor(Math.random()*n);

function conn(b,sx,sy){ if(b[sy*W+sx]!==1)return 0;
  const seen=new Uint8Array(W*H); const s=[[sx,sy]]; seen[sy*W+sx]=1; let n=0;
  while(s.length){const[x,y]=s.pop();n++;
    for(const[dx,dy]of DIRS){const nx=x+dx,ny=y+dy;
      if(nx<0||ny<0||nx>=W||ny>=H)continue;const i=ny*W+nx;
      if(!seen[i]&&b[i]===1){seen[i]=1;s.push([nx,ny]);}}}
  return n;}

function blob(b,N){ // ランダムウォークで連結した塊を作る
  let x=rnd(MAXX),y=rnd(H); const set=new Set(); 
  let guard=0;
  while(set.size<N && guard++<N*50){
    set.add(y*W+x);
    const[dx,dy]=DIRS[rnd(4)]; const nx=x+dx,ny=y+dy;
    if(nx>=0&&ny>=0&&nx<MAXX&&ny<H){x=nx;y=ny;}
  }
  for(const i of set) b[i]=1; return set.size;
}

function sample(N){
  const b=new Uint8Array(W*H); const placed=blob(b,N);
  let ax=rnd(MAXX),ay=rnd(H),dir=rnd(4),steps=0;
  while(steps<5000){
    const i=ay*W+ax;
    if(b[i]===0){b[i]=1;dir=(dir+1)&3;}else{b[i]=0;dir=(dir+3)&3;}
    ax+=DIRS[dir][0];ay+=DIRS[dir][1];steps++;
    if(ax<0||ay<0||ax>=W||ay>=H) return {ok:false,placed};
    if(ax>=BOUND){ b[ay*W+ax]=1; return {ok:true,placed,steps,dmg:conn(b,ax,ay)}; }
  }
  return {ok:false,placed};
}

for(const N of [10,25,50]){
  const T=200000; let arr=0; const d=[];
  for(let t=0;t<T;t++){const r=sample(N); if(r.ok){arr++;d.push(r.dmg);}}
  d.sort((a,b)=>a-b);
  const q=p=>d[Math.floor(d.length*p)];
  const ge=v=>d.filter(x=>x>=v).length;
  console.log(`塊${N}個 / ${T}回試行: 到達 ${(arr/T*100).toFixed(1)}%  ダメージ median=${q(.5)} p90=${q(.9)} p99=${q(.99)} max=${d[d.length-1]}  「ダメージ>=投入数」の割合=${(ge(N)/T*100).toFixed(3)}%`);
}
