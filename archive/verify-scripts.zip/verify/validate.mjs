// エンジン正当性の検証: 十分大きな盤面で、既知の「ハイウェイ」が約10,000ステップで出現するか
const N=400, DIRS=[[0,-1],[1,0],[0,1],[-1,0]];
const b=new Uint8Array(N*N);
let x=200,y=200,dir=0;
let minx=x,maxx=x,miny=y,maxy=y;
const marks=[];
for(let s=1;s<=12000;s++){
  const i=y*N+x;
  if(b[i]===0){b[i]=1;dir=(dir+1)&3;}else{b[i]=0;dir=(dir+3)&3;}
  x+=DIRS[dir][0];y+=DIRS[dir][1];
  minx=Math.min(minx,x);maxx=Math.max(maxx,x);miny=Math.min(miny,y);maxy=Math.max(maxy,y);
  if(s%2000===0) marks.push(`step ${String(s).padStart(5)}: 到達範囲 ${maxx-minx+1} x ${maxy-miny+1}`);
}
console.log(marks.join('\n'));
let black=0; for(const v of b) if(v) black++;
console.log(`\n12000ステップ後: 黒マス数=${black}, アリ位置=(${x-200},${y-200}) 開始点からの変位`);
console.log('※ 既知の性質: 約10,000ステップでカオス相が終わり、斜め方向のハイウェイが伸び始める');
console.log('→ 到達範囲が10000ステップ以降に一方向へ急伸していればエンジンは正しい');
// 40x20 での最長飛行の再確認
console.log('\n--- 40x20 盤面での飛行ステップ数の上限確認(全開始位置・全向きを網羅) ---');
const W=40,H=20,BOUND=20; let worst=0, cnt={arr:0,off:0};
for(let sx=0;sx<BOUND;sx++)for(let sy=0;sy<H;sy++)for(let d=0;d<4;d++){
  const bd=new Uint8Array(W*H); let ax=sx,ay=sy,dd=d,st=0,out=null;
  while(st<100000){const i=ay*W+ax;
    if(bd[i]===0){bd[i]=1;dd=(dd+1)&3;}else{bd[i]=0;dd=(dd+3)&3;}
    ax+=DIRS[dd][0];ay+=DIRS[dd][1];st++;
    if(ax<0||ay<0||ax>=W||ay>=H){out='off';break;}
    if(ax>=BOUND){out='arr';break;}}
  cnt[out]++; worst=Math.max(worst,st);
}
const total=BOUND*H*4;
console.log(`全 ${total} 通り(空盤面・全開始位置x全向き): 到達 ${cnt.arr} (${(cnt.arr/total*100).toFixed(1)}%) / 場外 ${cnt.off} / 最長飛行 ${worst} ステップ`);
