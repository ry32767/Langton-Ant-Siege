// 改善案の検証: 敵陣到達後も M ステップ走らせ、敵陣内に作った黒マスをダメージにする案
const W=40,H=20,BOUND=20;
const DIRS=[[0,-1],[1,0],[0,1],[-1,0]];
const rnd=n=>Math.floor(Math.random()*n);
const st=a=>{if(!a.length)return'n/a';const s=[...a].sort((x,y)=>x-y);const q=p=>s[Math.min(s.length-1,Math.floor(s.length*p))];
  return `median=${q(.5)} p75=${q(.75)} p95=${q(.95)} max=${s[s.length-1]} mean=${(a.reduce((x,y)=>x+y,0)/a.length).toFixed(1)}`;};

// 配置は境界から buffer 列は禁止(自陣 x in [0, BOUND-buffer))
function trial(nBlack, M, buffer, trials=20000){
  let arrived=0, off=0; const dmgs=[];
  for(let t=0;t<trials;t++){
    const b=new Uint8Array(W*H);
    const maxX=BOUND-buffer;
    for(let k=0;k<nBlack;k++) b[rnd(H)*W+rnd(maxX)]=1;
    let ax=rnd(maxX),ay=rnd(H),dir=rnd(4),steps=0,out=null;
    while(steps<200000){
      const i=ay*W+ax;
      if(b[i]===0){b[i]=1;dir=(dir+1)&3;}else{b[i]=0;dir=(dir+3)&3;}
      ax+=DIRS[dir][0];ay+=DIRS[dir][1];steps++;
      if(ax<0||ay<0||ax>=W||ay>=H){out='off';break;}
      if(ax>=BOUND){out='arr';break;}
    }
    if(out!=='arr'){off++;continue;}
    arrived++;
    // 敵陣で M ステップ走らせる(場外に出たら終了)
    let m=0;
    while(m<M){
      const i=ay*W+ax;
      if(b[i]===0){b[i]=1;dir=(dir+1)&3;}else{b[i]=0;dir=(dir+3)&3;}
      ax+=DIRS[dir][0];ay+=DIRS[dir][1];m++;
      if(ax<0||ay<0||ax>=W||ay>=H) break;
      // 自陣に戻っても継続(Mステップ走り切る)
    }
    // 敵陣内の黒マス数をダメージにする
    let c=0; for(let y=0;y<H;y++) for(let x=BOUND;x<W;x++) if(b[y*W+x]===1) c++;
    dmgs.push(c);
  }
  return {nBlack,M,buffer, 到達率:(arrived/trials*100).toFixed(1)+'%', ダメージ:st(dmgs)};
}

console.log('=== 改善案: 敵陣到達後 M ステップ走らせ、敵陣内の黒マス数をダメージにする ===');
for(const M of [30,60,120]) for(const n of [0,25,50]) console.log(trial(n,M,3));
