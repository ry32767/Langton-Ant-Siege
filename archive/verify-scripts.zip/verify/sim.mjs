// 仕様書 (spec.md / data-model.md) の既定値どおりの盤面でラングトンのアリを実測する
// 盤面: 40列 x 20行、左20列=自陣(player)、右20列=敵陣
// ルール: 白=右折して反転して前進 / 黒=左折して反転して前進

const W = 40, H = 20, BOUND = 20; // x >= BOUND が敵陣

const DIRS = [[0,-1],[1,0],[0,1],[-1,0]]; // up,right,down,left

function newBoard(w=W,h=H){ return new Uint8Array(w*h); } // 0=white 1=black

function connectedBlack(board, sx, sy, w=W, h=H, restrictEnemy=false){
  if(board[sy*w+sx] !== 1) return 0;
  const seen = new Uint8Array(w*h);
  const st=[[sx,sy]]; seen[sy*w+sx]=1; let n=0;
  while(st.length){
    const [x,y]=st.pop(); n++;
    for(const [dx,dy] of DIRS){
      const nx=x+dx, ny=y+dy;
      if(nx<0||ny<0||nx>=w||ny>=h) continue;
      if(restrictEnemy && nx<BOUND) continue;
      const i=ny*w+nx;
      if(!seen[i] && board[i]===1){ seen[i]=1; st.push([nx,ny]); }
    }
  }
  return n;
}

// 1回の発射をシミュレート
// placed: 事前配置する黒マス座標の配列 (自陣内)
function runShot(board, ax, ay, dir, maxSteps=200000){
  let steps=0;
  while(steps < maxSteps){
    const i = ay*W+ax;
    if(board[i]===0){ board[i]=1; dir=(dir+1)&3; }   // 白 -> 黒, 右折
    else            { board[i]=0; dir=(dir+3)&3; }   // 黒 -> 白, 左折
    ax += DIRS[dir][0]; ay += DIRS[dir][1];
    steps++;
    if(ax<0||ay<0||ax>=W||ay>=H) return {outcome:'offboard', steps, ax, ay};
    if(ax>=BOUND) return {outcome:'arrived', steps, ax, ay,
                          dmgAll: connectedBlack(board,ax,ay), // 到達マスは反転前なので0か。後で扱う
                          };
  }
  return {outcome:'timeout', steps};
}

function rnd(n){ return Math.floor(Math.random()*n); }

// --- 実験1: 空盤面、自陣内ランダム位置・ランダム向きから発射 ---
function exp1(trials=20000){
  const res={arrived:0, offboard:0, timeout:0};
  const arrSteps=[], offSteps=[];
  for(let t=0;t<trials;t++){
    const b=newBoard();
    const ax=rnd(BOUND), ay=rnd(H), d=rnd(4);
    const r=runShot(b,ax,ay,d);
    res[r.outcome]++;
    if(r.outcome==='arrived') arrSteps.push(r.steps);
    if(r.outcome==='offboard') offSteps.push(r.steps);
  }
  return {res, arrSteps, offSteps};
}

// --- 実験2: 自陣に黒マスをN個ランダム配置してから発射(トークン想定) ---
function exp2(nBlack, trials=20000){
  const res={arrived:0, offboard:0, timeout:0};
  const arrSteps=[], dmgs=[], dmgEnemy=[];
  for(let t=0;t<trials;t++){
    const b=newBoard();
    for(let k=0;k<nBlack;k++){ b[rnd(H)*W + rnd(BOUND)] = 1; }
    const ax=rnd(BOUND), ay=rnd(H), d=rnd(4);
    const r=runShot(b,ax,ay,d);
    res[r.outcome]++;
    if(r.outcome==='arrived'){
      arrSteps.push(r.steps);
      // 到達マスを黒とみなして連結数を数える(仕様の解釈A: 到達マス自身を黒扱い)
      b[r.ay*W+r.ax]=1;
      dmgs.push(connectedBlack(b,r.ax,r.ay));
      dmgEnemy.push(connectedBlack(b,r.ax,r.ay,W,H,true));
    }
  }
  return {res, arrSteps, dmgs, dmgEnemy};
}

// --- 実験3: 境界密着exploit。境界直前に連結した黒の塊+隣にアリ ---
function exp3(nBlack){
  const b=newBoard();
  // 境界(x=19)側に縦一列+左に伸ばして連結塊を作る
  let placed=0; const cells=[];
  outer:
  for(let x=BOUND-1; x>=0; x--){
    for(let y=0;y<H;y++){
      if(placed>=nBlack) break outer;
      b[y*W+x]=1; cells.push([x,y]); placed++;
    }
  }
  // アリを塊の中の境界セルに置き、右向き
  const ax=BOUND-1, ay=0;
  const r=runShot(b,ax,ay,1);
  let dmg=0, dmgE=0;
  if(r.outcome==='arrived'){ b[r.ay*W+r.ax]=1; dmg=connectedBlack(b,r.ax,r.ay); dmgE=connectedBlack(b,r.ax,r.ay,W,H,true); }
  return {placed, ...r, dmg, dmgE};
}

// --- 実験4: 盤面の高さを変えたときの到達率 ---
function expHeight(h, trials=8000){
  const w=W;
  const res={arrived:0,offboard:0,timeout:0}; const arrSteps=[];
  for(let t=0;t<trials;t++){
    const board=new Uint8Array(w*h);
    let ax=rnd(BOUND), ay=rnd(h), dir=rnd(4), steps=0, out=null;
    while(steps<200000){
      const i=ay*w+ax;
      if(board[i]===0){ board[i]=1; dir=(dir+1)&3; } else { board[i]=0; dir=(dir+3)&3; }
      ax+=DIRS[dir][0]; ay+=DIRS[dir][1]; steps++;
      if(ax<0||ay<0||ax>=w||ay>=h){ out='offboard'; break; }
      if(ax>=BOUND){ out='arrived'; break; }
    }
    if(!out) out='timeout';
    res[out]++; if(out==='arrived') arrSteps.push(steps);
  }
  return {h, res, arrSteps};
}

// --- 実験5: 上下ラップ(トーラス)にした場合 ---
function expWrap(h, trials=8000){
  const w=W;
  const res={arrived:0,offboard:0,timeout:0}; const arrSteps=[];
  for(let t=0;t<trials;t++){
    const board=new Uint8Array(w*h);
    let ax=rnd(BOUND), ay=rnd(h), dir=rnd(4), steps=0, out=null;
    while(steps<200000){
      const i=ay*w+ax;
      if(board[i]===0){ board[i]=1; dir=(dir+1)&3; } else { board[i]=0; dir=(dir+3)&3; }
      ax+=DIRS[dir][0]; ay+=DIRS[dir][1]; steps++;
      ay=(ay+h)%h;
      if(ax<0){ out='offboard'; break; }
      if(ax>=BOUND){ out='arrived'; break; }
    }
    if(!out) out='timeout';
    res[out]++; if(out==='arrived') arrSteps.push(steps);
  }
  return {h,res,arrSteps};
}

function stats(a){
  if(!a.length) return 'n/a';
  const s=[...a].sort((x,y)=>x-y);
  const q=p=>s[Math.min(s.length-1, Math.floor(s.length*p))];
  const mean=(a.reduce((x,y)=>x+y,0)/a.length);
  return `n=${a.length} min=${s[0]} p25=${q(.25)} median=${q(.5)} p75=${q(.75)} p95=${q(.95)} max=${s[s.length-1]} mean=${mean.toFixed(1)}`;
}

console.log('=== 実験1: 空盤面(黒マス0個)、40x20、自陣ランダム位置から発射 20000回 ===');
const e1=exp1();
console.log('結果:', e1.res, `到達率 ${(e1.res.arrived/200).toFixed(2)}%`);
console.log('  到達までのステップ:', stats(e1.arrSteps));
console.log('  場外までのステップ:', stats(e1.offSteps));

for(const n of [10,25,50]){
  console.log(`\n=== 実験2: 自陣に黒マス${n}個をランダム配置してから発射 20000回 ===`);
  const e=exp2(n);
  console.log('結果:', e.res, `到達率 ${(e.res.arrived/200).toFixed(2)}%`);
  console.log('  到達ステップ:', stats(e.arrSteps));
  console.log('  ダメージ(盤面全体の連結黒マス数):', stats(e.dmgs));
  console.log('  ダメージ(敵陣内に限定した場合):', stats(e.dmgEnemy));
}

console.log('\n=== 実験3: 境界密着exploit(境界寄りに連結した黒の塊+境界隣にアリ) ===');
for(const n of [10,25,50]) console.log(` 黒${n}個:`, exp3(n));

console.log('\n=== 実験4: 盤面の高さを変えたときの到達率(黒0個, 幅40/境界20固定) ===');
for(const h of [20,40,60,100,200]){
  const e=expHeight(h);
  console.log(` 高さ${String(h).padStart(3)}: 到達 ${(e.res.arrived/80).toFixed(2)}%  場外 ${(e.res.offboard/80).toFixed(2)}%  到達ステップ ${stats(e.arrSteps)}`);
}

console.log('\n=== 実験5: 上下をラップ(トーラス)にした場合の到達率 ===');
for(const h of [20,40,60]){
  const e=expWrap(h);
  console.log(` 高さ${String(h).padStart(3)}(ラップ): 到達 ${(e.res.arrived/80).toFixed(2)}%  場外(自陣端) ${(e.res.offboard/80).toFixed(2)}%  タイムアウト ${e.res.timeout}  到達ステップ ${stats(e.arrSteps)}`);
}
