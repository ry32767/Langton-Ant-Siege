# データモデル

背景は [../README.md](../README.md)、機能・受け入れ条件は [spec.md](spec.md)、全体構成は [architecture.md](architecture.md)。

```mermaid
erDiagram
    SIDE ||--o{ ANT : owns
    ANT ||--o{ CELL : "lastFlippedBy(0..1)"
    SIDE {
        string id "player または cpu"
        int hp
        int tokens
        int tokenCap
    }
    ANT {
        string id
        string sideId FK
        int x
        int y
        string direction "up/down/left/right"
        bool alive
    }
    CELL {
        int x
        int y
        string state "black または white"
        string lastFlippedByAntId FK "nullable"
    }
    BOARD {
        int width
        int height
        string splitAxis "左右 または 上下"
        int boundaryIndex
    }
    TEMPLATE {
        string id
        int cost
        int arrivalStep
        int expectedDamage
        float successRate
        string featureBin "MAP-Elitesの特徴軸(costTier x speedTier)"
    }
```

| エンティティ | 主なフィールド | 補足 |
|---|---|---|
| Side(陣営) | `id`(player/cpu), `hp`, `tokens`, `tokenCap` | `tokens` は1秒ごとに+1、`tokenCap` で頭打ち(既定50) |
| Ant(アリ) | `id`, `sideId`, `x`, `y`, `direction`, `alive` | ラングトンのアリのルールで自律的に移動。到達 or 場外で `alive=false` |
| Cell(マス) | `x`, `y`, `state`, `lastFlippedByAntId` | ダメージ計算(連結黒マス数)は `state` のみ参照。リセットは `lastFlippedByAntId` が到達したアリと一致するマスだけを対象にする |
| Board(盤面) | `width`, `height`, `splitAxis`, `boundaryIndex` | 1枚の盤面を自陣/敵陣に分割する境界を保持(既定：左右20列ずつ、計40列×20行) |
| Template(CPU用) | `id`, `cost`, `arrivalStep`, `expectedDamage`, `successRate`, `featureBin` | `scripts/generate-templates.mjs` がオフラインで生成し `data/templates.json` に保存。実際の黒マス座標リストとアリの初期位置・向きも同ファイルに含む |
