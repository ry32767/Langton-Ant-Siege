# ドキュメント

全体概要は [../README.md](../README.md)、作業規約は [../AGENTS.md](../AGENTS.md)。

| ドキュメント | 内容 |
|---|---|
| [spec.md](spec.md) | 機能・受け入れ条件・タスク(契約書) |
| [data-model.md](data-model.md) | セル・アリ・陣営・CPUテンプレートのデータ構造 |
| [architecture.md](architecture.md) | オフライン事前学習＋実行時テーブル参照という構成の設計判断 |
