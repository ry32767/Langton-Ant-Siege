# AGENTS.md

> このプロジェクトでコードを書く**すべての AI エージェント(Codex / Cursor / Claude Code など)共通の作業規約**。作業前に読むこと。Claude Code は `CLAUDE.md` 経由で読み込む。

## ドキュメントの役割
- **README.md**(直下・人間向け)：概要・フォルダ構成・使い方。AI 専用手順は書かない。
- **AGENTS.md**(このファイル)：作業規約・コマンド・検証ループ・ドキュメント同期規約。
- **CLAUDE.md**(直下)：Claude Code 固有の補足のみ(このファイルを読み込む薄いラッパ)。
- **docs/**：`spec.md`(仕様・受け入れ条件=合格ライン)、`README.md`(索引)、`data-model.md`、`architecture.md`。

作業前に：概要は README.md、実装する機能と受け入れ条件は `docs/spec.md`、セル/アリ/テンプレートの形は `docs/data-model.md`、CPU設計や全体構成の判断は `docs/architecture.md` を読む。

## Tech Stack
| レイヤー | 技術 |
|---|---|
| フロントエンド | バニラ JavaScript + HTML5 Canvas(ビルド不要) |
| CPUテンプレート生成 | Node.js スクリプト(開発時のみ実行、依存パッケージ無し) |
| Backend / DB | なし(静的サイト) |
| Deploy | GitHub Pages |

## Commands
```bash
npx serve .                              # ローカルで動作確認(index.html をブラウザで開く)
node --test                              # src/ の単体テスト(Node組み込みテストランナー)
node scripts/generate-templates.mjs      # CPU用テンプレートを再生成し data/templates.json を更新
```

## Verification Loop(検証ループ)
**機能を実装したら、完了宣言の前に必ず回す。** 最重要の規約。

1. 実装する
2. 検証する：`node --test`(該当する単体テストがあれば実行)。CPUロジックやテンプレート生成ロジックに変更を加えた場合は `node scripts/generate-templates.mjs` を再実行し `data/templates.json` を更新
3. `docs/spec.md` の該当機能の**受け入れ条件**を1つずつ照合(自動テストが無いものは `npx serve .` でブラウザ手動確認)
4. 1つでも失敗・未達なら原因を直して 2 に戻る
5. すべて green かつ全受け入れ条件 ○ で初めて「完了」

ルール：テストにエラーがある状態で「完了」と言わない。仕様の不備で満たせないときは `docs/spec.md` の「未決定事項」に追記して相談。手動確認は何をどう確認したか一言報告。テストの無い受け入れ条件は可能なら先にテストを書く。

## ドキュメント同期規約
コードだけ進んで docs が古くなると土台が嘘になる。だから：
- **仕様や挙動を変えたら、対応するドキュメントを同じ変更(コミット)で更新する**：機能・受け入れ条件・タスク→`docs/spec.md`、セル/アリ/陣営/テンプレートの形→`docs/data-model.md`、CPU設計や全体構成の判断→`docs/architecture.md`、使い方・セットアップ→`README.md`。
- **docs を増減したら `docs/README.md` の索引も直す。** Mermaid 図を持つ docs は実装とズレたら図も直す。
- 今すぐ直せないズレは `docs/spec.md` の「未決定事項」に残して放置しない。

## コーディング規約
- `src/engine.js` はブラウザ・Node のどちらからも読み込める純粋な JS にする(DOM や `window` に依存しない)。オフラインのテンプレート生成スクリプト(`scripts/generate-templates.mjs`)と、実行時のブラウザロジックの両方から同じシミュレーションコードを共有するため
- コメントは日本語でよい

## Do NOT
- `src/engine.js` に DOM 依存コードを混ぜない(Node のテンプレート生成スクリプトから使えなくなる)
- README.md に AI 向け手順を書かない(人間向けに保つ)
- 仕様を変えたのに docs を直さず「完了」と言わない
- `data/templates.json` を手で直接編集しない(ロジックを直したら `scripts/generate-templates.mjs` を再実行して更新)
