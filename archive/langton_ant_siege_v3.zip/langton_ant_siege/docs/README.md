# ドキュメント

全体概要は [../README.md](../README.md)、作業規約は [../AGENTS.md](../AGENTS.md)。

| ドキュメント | 内容 |
|---|---|
| [spec.md](spec.md) | ゲームルール・機能・受け入れ条件・検証戦略・タスク(契約書) |
| [data-model.md](data-model.md) | 盤面・アリ・陣営・テンプレート・方策のデータ構造とJSONの形 |
| [architecture.md](architecture.md) | オフライン事前生成＋実行時テーブル参照という構成の設計判断と、実測に基づく所要時間 |
| [../REVIEW.md](../REVIEW.md) | 実測レビュー(v1本編 + 付録B: ダメージ定義の検証 + 付録C: ハイウェイとジオメトリの検証)。現仕様の各制約が「なぜ必要か」の根拠 |
