# データモデル

背景は [../README.md](../README.md)、機能・受け入れ条件は [spec.md](spec.md)、全体構成は [architecture.md](architecture.md)。

```mermaid
erDiagram
    MATCH ||--|| BOARD : uses
    MATCH ||--o{ SIDE : has
    SIDE ||--o{ ANT : "flying(0..4)"
    ANT ||--o{ PLACEDCELL : placed
    TEMPLATE ||--o{ TEMPLATECELL : contains
    MATCH {
        int stepsPerSecond "既定120"
        int timeLimitSec "既定240"
        int winScore "既定5"
        int elapsedStep
        string phase "playing または finished"
        string result "side1 / side2 / draw / null"
        int seed "擬似乱数シード"
    }
    BOARD {
        int width "120"
        int height "60"
        int zoneDepth "16"
        bool wrapVertical "true"
    }
    SIDE {
        string id "side1 または side2"
        string controller "human または cpu"
        bool mirrored "side2 は true"
        int score
        int tokens
        int tokenCap "既定30"
        int maxFlying "既定4"
    }
    ANT {
        int id "盤面で一意"
        string sideId FK
        string kind "attack または disrupt"
        int x
        int y
        int direction "0=up 1=right 2=down 3=left"
        int steps
        int life "attack=2400 / disrupt=400"
    }
    PLACEDCELL {
        int antId FK
        int x
        int y
    }
    TEMPLATE {
        string id
        string kind "attack または disrupt"
        int cost
        int arrivalStep "attack のみ"
        int reachColumns "disrupt のみ"
        int endDirection "disrupt のみ"
        int costTier
        int featureTier
    }
    TEMPLATECELL {
        string templateId FK
        int x
        int y
    }
```

| エンティティ | 主なフィールド | 補足 |
|---|---|---|
| Match(試合) | `stepsPerSecond`, `timeLimitSec`, `winScore`, `elapsedStep`, `phase`, `result`, `seed` | 先に `winScore` 到達で勝ち。240秒で得点比較、同点なら `draw` |
| Board(盤面) | `width`, `height`, `zoneDepth`, `wrapVertical` | side1 の配置可能帯は x=0..15、side2 は x=104..119。上下ラップ、左右端でアリ消滅 |
| Side(陣営) | `id`, `controller`, `mirrored`, `score`, `tokens`, `tokenCap`, `maxFlying` | `tokens` は1秒ごとに+1(上限30)。アリ飛行中も蓄積。同時飛行は最大4匹 |
| Ant(アリ) | `id`, `sideId`, `kind`, `x`, `y`, `direction`, `steps`, `life` | `kind` で寿命が決まる(attack=2400 / disrupt=400)。`steps >= life` で消滅 |
| PlacedCell(配置マス) | `antId`, `x`, `y` | **アリ単位**で持つ(陣営単位ではない)。そのアリの消滅時にクリーンアップ対象になる |
| Template(テンプレート) | `id`, `kind`, `cost`, `arrivalStep` / `reachColumns` / `endDirection`, `costTier`, `featureTier` | 攻撃用と妨害用で特徴軸が異なる |
| TemplateCell | `templateId`, `x`, `y` | 配置マスの座標。アリの初期位置・向きは Template に `antX` / `antY` / `antDir` として持つ |

## 盤面の内部表現

```js
board       = new Uint8Array(W * H);   // 0 / 1 / 2 の3状態
lastToucher = new Int16Array(W * H);   // 最後にそのマスを踏んだアリの id。-1 = 誰も踏んでいない
```

セルはオブジェクト化しない。120×60 = 7,200セルなのでコピーも探索も安価。

### クリーンアップ

アリ `a` が消滅したとき、白(状態0)に戻すのは次の集合。

```
{ a.placedCells のうち lastToucher[i] が -1 または a.id のもの }
∪ { lastToucher[i] === a.id であるすべてのマス }
```

`lastToucher` を見ることで、**他のアリが後から踏んだマスは残す**。複数アリが干渉する v3 では、単純な一括クリアだと他のアリの軌跡を壊してしまうため必須。

> v2 の `Ant.flippedCells`(アリ側が集合を持つ方式)は廃止した。他のアリが上書きしたかどうかを判定できないため。

## 座標系

エンジンは **side1 のローカル座標**で動く。side2 のアクセスは `xGlobal = 119 - xLocal`、向きは left⇄right を入れ替える([spec.md](spec.md) の「陣営の座標系」)。`Side.mirrored` でどちらかを保持する。

## data/templates.json

```json
{
  "generatedAt": "2026-08-06T00:00:00Z",
  "config": { "width": 120, "height": 60, "zoneDepth": 16, "rule": "RRL",
              "attackCost": 5, "attackLife": 2400,
              "disruptCost": 3, "disruptLife": 400, "maxCells": 16 },
  "attack": [
    {
      "id": "a12t03",
      "cells": [[3, 21], [3, 22], [4, 22]],
      "antX": 14, "antY": 23, "antDir": 1,
      "cost": 8,
      "arrivalStep": 1743,
      "costTier": 8,
      "featureTier": 3
    }
  ],
  "disrupt": [
    {
      "id": "d05r28e1",
      "cells": [[6, 40], [6, 41]],
      "antX": 5, "antY": 41, "antDir": 1,
      "cost": 5,
      "reachColumns": 20,
      "endDirection": 1,
      "costTier": 5,
      "featureTier": 2
    }
  ]
}
```

座標・向きはすべて **side1 ローカル座標**。side2 が使うときにミラーリング変換をかける。

> ⚠️ 上の2件は**形式を示す例**であり、実在の生成結果ではない。値の整合は生成スクリプトが保証する(例: `antX=14` から x=104 までは90列＝最短1,620ステップなので `arrivalStep: 1743` は妥当。`reachColumns: 20` は寿命400 × 0.0556列/ステップ＝最大22列の範囲内)。

| 種類 | 特徴軸1 | 特徴軸2 |
|---|---|---|
| 攻撃 (`attack`) | `costTier` = cost の値(5..21 の17段階) | `featureTier` = 到達ステップのビン(0..5 の6段階) |
| 妨害 (`disrupt`) | `costTier` = cost の値(3..19 の17段階) | `featureTier` = 到達距離のビン(0..5 の6段階) × 到達時の向き |

## data/policy.json

```json
{
  "trainedAt": "2026-08-06T00:00:00Z",
  "method": "CEM",
  "generations": 40,
  "matches": 96000,
  "winRateVsRandom": 0.0,
  "policy": { "fireThreshold": 8, "defendBias": 0.5, "wTime": 0.3, "wCost": 0.1 }
}
```

| フィールド | 意味 |
|---|---|
| `fireThreshold` | このトークン数以上でのみ発射を検討する |
| `defendBias` | 敵のアリが飛行中のとき、妨害アリを選ぶ確率 |
| `wTime` / `wCost` | `Utility = -wTime × (arrivalStep / stepsPerSecond) - wCost × cost`(到達1回=1得点なので、得点そのものは順位に影響しない) |
| `winRateVsRandom` | 学習の効果を示す記録値。再学習したら更新する |

> ⚠️ 上の値は**形式を示す例**であり実在の学習結果ではない。`node scripts/train-policy.mjs` を実行して実際の値で上書きすること。
>
> `data/*.json` は手で編集しない。ロジックを直したらスクリプトを再実行する([../AGENTS.md](../AGENTS.md) の Do NOT)。
