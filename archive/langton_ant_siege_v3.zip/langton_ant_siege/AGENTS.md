# AGENTS.md

> このプロジェクトでコードを書く**すべての AI エージェント(Codex / Cursor / Claude Code など)共通の作業規約**。作業前に読むこと。Claude Code は `CLAUDE.md` 経由で読み込む。

## ドキュメントの役割
- **README.md**(直下・人間向け)：概要・フォルダ構成・使い方。AI 専用手順は書かない。
- **AGENTS.md**(このファイル)：作業規約・コマンド・検証ループ・ドキュメント同期規約。
- **CLAUDE.md**(直下)：Claude Code 固有の補足のみ(このファイルを読み込む薄いラッパ)。
- **docs/**：`spec.md`(ゲームルール・受け入れ条件=合格ライン)、`README.md`(索引)、`data-model.md`、`architecture.md`。
- **REVIEW.md**(直下)：実測レビュー(v1本編 + 付録B/C)。現仕様の制約の根拠。**ルールを変えたくなったら先にこれを読む。**

作業前に：概要は README.md、**ゲームルールと受け入れ条件は `docs/spec.md`(第2章のルール表は全機能の前提)**、盤面/アリ/テンプレートの形は `docs/data-model.md`、CPU設計や全体構成の判断は `docs/architecture.md` を読む。

## Tech Stack
| レイヤー | 技術 |
|---|---|
| フロントエンド | バニラ JavaScript (ESM) + HTML5 Canvas(ビルド不要) |
| オフライン処理 | Node.js スクリプト(開発時のみ実行、依存パッケージ無し) |
| Backend / DB | なし(静的サイト) |
| Deploy | GitHub Pages |

## Commands
```bash
npx serve .                                  # ローカルで動作確認(HTTPサーバー必須。file:// では動かない)
node --test                                  # src/ の単体テスト(Node組み込みテストランナー)
node scripts/generate-templates.mjs          # CPU/プレイヤー用テンプレートを再生成 → data/templates.json
node scripts/train-policy.mjs                # CPU同士の自己対戦で方策を学習 → data/policy.json
node scripts/simulate-matches.mjs --games 5000             # バランス検証(得点率・HW割合・盤面汚染度・先手勝率)
node scripts/simulate-matches.mjs --games 100 --seed 1    # シード固定で再現性を確認(2回実行して出力一致)
```

## Verification Loop(検証ループ)
**機能を実装したら、完了宣言の前に必ず回す。** 最重要の規約。

1. 実装する
2. 検証する：`node --test`(該当する単体テストがあれば実行)
3. **ルール・数値・エンジンに手を入れた場合は `node scripts/simulate-matches.mjs --games 5000` を実行し、`docs/spec.md` の「バランス指標」の範囲内に収まっているか確認する**
4. テンプレート生成ロジックや `src/engine.js` を変えた場合は `node scripts/generate-templates.mjs` → `node scripts/train-policy.mjs` を再実行し `data/*.json` を更新
5. `docs/spec.md` の該当機能の**受け入れ条件**を1つずつ照合(自動テストが無いものは `npx serve .` でブラウザ手動確認)
6. 1つでも失敗・未達なら原因を直して 2 に戻る
7. すべて green かつ全受け入れ条件 ○ かつバランス指標が範囲内で初めて「完了」

ルール：テストにエラーがある状態で「完了」と言わない。仕様の不備で満たせないときは `docs/spec.md` の「未決定事項」に追記して相談。手動確認は何をどう確認したか一言報告。テストの無い受け入れ条件は可能なら先にテストを書く。

## バランスに関わる変更の規律
ゲームルールと数値は**実測に基づいて決まっている**。目視では破綻に気づけないことが v1 レビューで実証済み。だから：

- **ルールや数値を変えたら、必ず `simulate-matches.mjs` を回して数値で確認する。** 「良くなった気がする」で確定しない
- 特に **得点弾のハイウェイ割合(95%以上)** と **妨害の阻止率(70〜95%)** は、この作品の面白さそのものなので毎回見る
- 数値は `src/config.js` に一元化し、ハードコードしない
- 以下の制約は**外すと壊れることが実測済み**。外したくなったら先に `REVIEW.md` を読み、理由を `docs/spec.md` の決定事項に書いてから変える
  - **アリの寿命(攻撃2,400 / 妨害400)** — これが「ハイウェイ以外を落とす」唯一の仕組み。緩めると成立しなくなる
  - **配置可能域を自陣の端16列に限定** — 広げると横断距離が縮み、ハイウェイが不要になる
  - **RRL(3色)ルール** — 古典RL(2色)に戻すと、ハイウェイ形成に9,976ステップかかり寿命内に届かない
  - **`lastToucher` によるクリーンアップ** — 単純な一括クリアにすると他のアリの軌跡を壊す
  - **防御はブロックではなく妨害アリ** — 配置ブロックによる防御は実測で効果ゼロ

## ドキュメント同期規約
コードだけ進んで docs が古くなると土台が嘘になる。だから：
- **仕様や挙動を変えたら、対応するドキュメントを同じ変更(コミット)で更新する**：ゲームルール・機能・受け入れ条件・タスク→`docs/spec.md`、盤面/アリ/陣営/テンプレート/方策の形→`docs/data-model.md`、CPU設計や全体構成の判断→`docs/architecture.md`、使い方・セットアップ→`README.md`。
- **`src/config.js` の数値を変えたら `docs/spec.md` 第2章のルール表も同じ変更で直す。**
- **docs を増減したら `docs/README.md` の索引も直す。** Mermaid 図を持つ docs は実装とズレたら図も直す。
- 今すぐ直せないズレは `docs/spec.md` の「未決定事項」に残して放置しない。

## コーディング規約
- `src/engine.js` はブラウザ・Node のどちらからも読み込める純粋な JS(ESM)にする(DOM や `window` に依存しない)。オフラインの生成・学習・検証スクリプトと、実行時のブラウザロジック・先読みシミュレーションの**すべてが同じコードを共有する**ため
- 盤面は `Uint8Array` で持つ(セルをオブジェクト化しない)
- 数値定数は `src/config.js` に集約する
- コメントは日本語でよい

## Do NOT
- `src/engine.js` に DOM 依存コードを混ぜない(Node のスクリプトから使えなくなる)
- 数値をソースに直書きしない(`src/config.js` に置く)
- **バランスに関わる変更を `simulate-matches.mjs` で確認せずに完了と言わない**
- README.md に AI 向け手順を書かない(人間向けに保つ)
- 仕様を変えたのに docs を直さず「完了」と言わない
- `data/templates.json` `data/policy.json` を手で直接編集しない(ロジックを直したらスクリプトを再実行して更新)
