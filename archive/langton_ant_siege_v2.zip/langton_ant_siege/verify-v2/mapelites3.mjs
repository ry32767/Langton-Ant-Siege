// MAP-Elites によるテンプレート生成 + 所要時間/品質の実測
import { W,H,MAXX, evaluate } from './engine3.mjs';

const rnd = n => Math.floor(Math.random()*n);
const MAX_COST = 20;                     // トークン上限20の提案に合わせる
const SPEED_BINS = [50, 150, 400, Infinity];  // 到達ステップ数のtier
const NSPEED = SPEED_BINS.length;
const NCOST = MAX_COST + 1;              // コストは実数値でbin(0..20)

function speedTier(steps){ for(let i=0;i<NSPEED;i++) if(steps<=SPEED_BINS[i]) return i; return NSPEED-1; }
function binOf(r){ return r.cost*NSPEED + speedTier(r.steps); }

function randomTemplate(){
  const n = rnd(MAX_COST+1);
  const set = new Set();
  let x=rnd(MAXX), y=rnd(H), guard=0;
  while(set.size<n && guard++<n*40){
    set.add(y*W+x);
    const d=[[0,-1],[1,0],[0,1],[-1,0]][rnd(4)];
    const nx=x+d[0], ny=(y+d[1]+H)%H;
    if(nx>=0&&nx<MAXX){x=nx;y=ny;}
  }
  return { cells:[...set].map(i=>[i%W,Math.floor(i/W)]), ant:[rnd(MAXX),rnd(H),rnd(4)] };
}

function mutate(t){
  const cells = t.cells.map(c=>[c[0],c[1]]);
  let ant = [...t.ant];
  const op = rnd(6);
  if (op===0 && cells.length<MAX_COST) cells.push([rnd(MAXX), rnd(H)]);        // 追加
  else if (op===1 && cells.length>0) cells.splice(rnd(cells.length),1);         // 削除
  else if (op===2 && cells.length>0){                                           // 1マス移動
    const k=rnd(cells.length); const d=[[0,-1],[1,0],[0,1],[-1,0]][rnd(4)];
    const nx=cells[k][0]+d[0], ny=(cells[k][1]+d[1]+H)%H;
    if(nx>=0&&nx<MAXX) cells[k]=[nx,ny];
  }
  else if (op===3){ ant[0]=rnd(MAXX); ant[1]=rnd(H); }                          // アリ移動
  else if (op===4){ ant[2]=rnd(4); }                                            // アリ回転
  else if (cells.length>0){                                                     // 塊ごと平行移動
    const dx=rnd(3)-1, dy=rnd(3)-1;
    for(let k=0;k<cells.length;k++){ const nx=cells[k][0]+dx; if(nx>=0&&nx<MAXX) cells[k]=[nx,(cells[k][1]+dy+H)%H]; }
  }
  // 重複除去
  const seen=new Set(); const uniq=[];
  for(const c of cells){ const k=c[1]*W+c[0]; if(!seen.has(k)){seen.add(k);uniq.push(c);} }
  return { cells:uniq, ant };
}

export function run(budget, initRandom=2000, log=false){
  const archive = new Map();   // bin -> {tpl, damage, cost, steps}
  const t0 = process.hrtime.bigint();
  let evals=0;

  const tryAdd = t => {
    const r = evaluate(t, 3000); evals++;
    if (r.outcome!=='arrived') return;
    const b = binOf(r);
    const cur = archive.get(b);
    if (!cur || r.damage > cur.damage) archive.set(b, {tpl:t, ...r});
  };

  for(let i=0;i<initRandom;i++) tryAdd(randomTemplate());
  const marks=[];
  const checkpoints=[1e5,1e6,5e6,1e7,3e7].filter(c=>c<=budget);
  let ci=0;
  while(evals<budget){
    const keys=[...archive.keys()];
    const parent = keys.length ? archive.get(keys[rnd(keys.length)]).tpl : randomTemplate();
    tryAdd(mutate(parent));
    if(ci<checkpoints.length && evals>=checkpoints[ci]){
      const ms=Number(process.hrtime.bigint()-t0)/1e6;
      marks.push({evals, sec:+(ms/1000).toFixed(1), 埋まったマス:archive.size, 最大ダメージ:Math.max(...[...archive.values()].map(v=>v.damage))});
      ci++;
    }
  }
  const ms=Number(process.hrtime.bigint()-t0)/1e6;
  return {archive, evals, sec:ms/1000, marks};
}

if (process.argv[2]){
  const budget = Number(process.argv[2]);
  const {archive, sec, marks} = run(budget, 5000);
  console.log(`\n=== MAP-Elites: ${budget.toLocaleString()} 評価 / ${sec.toFixed(1)}秒 (1スレッド) ===`);
  console.log('進捗:'); for(const m of marks) console.log('  ', JSON.stringify(m));
  console.log(`\nアーカイブ: ${archive.size} / ${NCOST*NSPEED} マス埋まり`);
  console.log('\nコスト別のベスト(全speed tier横断):');
  const byCost=new Map();
  for(const v of archive.values()){ const c=v.cost; if(!byCost.has(c)||byCost.get(c).damage<v.damage) byCost.set(c,v); }
  console.log(' cost | 最大ダメージ | 到達ステップ | ダメージ/コスト');
  for(const c of [...byCost.keys()].sort((a,b)=>a-b)){
    const v=byCost.get(c);
    console.log(`  ${String(c).padStart(3)} | ${String(v.damage).padStart(11)} | ${String(v.steps).padStart(11)} | ${c?(v.damage/c).toFixed(2):'-'}`);
  }
}
