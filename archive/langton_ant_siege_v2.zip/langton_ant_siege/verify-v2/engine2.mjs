// 改訂ルール版エンジン(レビュー 5-1 / 5-3 の提案を反映)
// - 盤面 40x20、左20列=自陣、右20列=敵陣
// - 上下はラップ(トーラス)。場外は自陣側の端(x<0)のみ
// - 境界から BUFFER 列は配置禁止
// - ダメージ = 到達マスを黒とみなしたときの4連結黒マス数(盤面全体)
// - 数えた黒マスはすべて白に戻す(消費)

export const W = 40, H = 20, BOUND = 20, BUFFER = 3;
export const MAXX = BOUND - BUFFER;          // 配置可能 x: 0..MAXX-1 (=0..16)
export const DIRS = [[0,-1],[1,0],[0,1],[-1,0]]; // 0=up 1=right 2=down 3=left

export function idx(x,y){ return y*W+x; }

// 1発シミュレート。board は Uint8Array(W*H) を破壊的に更新する。
// 戻り値: {outcome:'arrived'|'offboard'|'timeout', steps, damage, cells}
export function simulate(board, antX, antY, antDir, maxSteps = 3000){
  let x = antX, y = antY, dir = antDir, steps = 0;
  while (steps < maxSteps){
    const i = idx(x,y);
    if (board[i] === 0){ board[i] = 1; dir = (dir + 1) & 3; }
    else               { board[i] = 0; dir = (dir + 3) & 3; }
    x += DIRS[dir][0];
    y = (y + DIRS[dir][1] + H) % H;   // 上下ラップ
    steps++;
    if (x < 0)      return { outcome:'offboard', steps, damage:0 };
    if (x >= BOUND){
      board[idx(x,y)] = 1;            // 到達マスを黒として扱う
      const cells = floodBlack(board, x, y);
      for (const c of cells) board[c] = 0;   // 数えたマスは消費(白に戻す)
      return { outcome:'arrived', steps, damage: cells.length, cells };
    }
  }
  return { outcome:'timeout', steps, damage:0 };
}

// 4連結の黒マス集合(上下ラップを考慮)
export function floodBlack(board, sx, sy){
  const out = [];
  if (board[idx(sx,sy)] !== 1) return out;
  const seen = new Uint8Array(W*H);
  const st = [[sx,sy]];
  seen[idx(sx,sy)] = 1;
  while (st.length){
    const [x,y] = st.pop();
    out.push(idx(x,y));
    for (const [dx,dy] of DIRS){
      const nx = x + dx;
      if (nx < 0 || nx >= W) continue;
      const ny = (y + dy + H) % H;
      const i = idx(nx,ny);
      if (!seen[i] && board[i] === 1){ seen[i] = 1; st.push([nx,ny]); }
    }
  }
  return out;
}

// テンプレート(黒マス座標 + アリ)を空盤面で評価する
export function evaluate(tpl, maxSteps = 3000){
  const b = new Uint8Array(W*H);
  for (const [x,y] of tpl.cells) b[idx(x,y)] = 1;
  const r = simulate(b, tpl.ant[0], tpl.ant[1], tpl.ant[2], maxSteps);
  return { cost: tpl.cells.length, damage: r.damage, steps: r.steps, outcome: r.outcome };
}
