import { W,H,MAXX, evaluate } from './engine4.mjs';
const rnd=n=>Math.floor(Math.random()*n);
const MAX_COST=20;
// 到達ステップの tier を実プレイ時間に合わせて細かく取る(30ステップ/秒 想定)
const SPEED_BINS=[30,60,120,240,480,960,3000];
const NS=SPEED_BINS.length, NC=MAX_COST+1;
const st=s=>{for(let i=0;i<NS;i++) if(s<=SPEED_BINS[i]) return i; return NS-1;};
function randT(){const n=rnd(MAX_COST+1);const s=new Set();let x=rnd(MAXX),y=rnd(H),g=0;
  while(s.size<n&&g++<n*40){s.add(y*W+x);const d=[[0,-1],[1,0],[0,1],[-1,0]][rnd(4)];const nx=x+d[0],ny=(y+d[1]+H)%H;if(nx>=0&&nx<MAXX){x=nx;y=ny;}}
  return {cells:[...s].map(i=>[i%W,Math.floor(i/W)]),ant:[rnd(MAXX),rnd(H),rnd(4)]};}
function mut(t){const c=t.cells.map(a=>[a[0],a[1]]);let ant=[...t.ant];const op=rnd(6);
  if(op===0&&c.length<MAX_COST)c.push([rnd(MAXX),rnd(H)]);
  else if(op===1&&c.length)c.splice(rnd(c.length),1);
  else if(op===2&&c.length){const k=rnd(c.length);const d=[[0,-1],[1,0],[0,1],[-1,0]][rnd(4)];const nx=c[k][0]+d[0];if(nx>=0&&nx<MAXX)c[k]=[nx,(c[k][1]+d[1]+H)%H];}
  else if(op===3){ant[0]=rnd(MAXX);ant[1]=rnd(H);}
  else if(op===4){ant[2]=rnd(4);}
  else if(c.length){const dx=rnd(3)-1,dy=rnd(3)-1;for(let k=0;k<c.length;k++){const nx=c[k][0]+dx;if(nx>=0&&nx<MAXX)c[k]=[nx,(c[k][1]+dy+H)%H];}}
  const sn=new Set(),u=[];for(const a of c){const k=a[1]*W+a[0];if(!sn.has(k)){sn.add(k);u.push(a);}}
  return {cells:u,ant};}

const BUDGET=Number(process.argv[2]||5e6);
const arc=new Map(); let ev=0;
const t0=process.hrtime.bigint();
const add=t=>{const r=evaluate(t,3000);ev++;if(r.outcome!=='arrived')return;
  const b=r.cost*NS+st(r.steps);const cur=arc.get(b);
  if(!cur||r.damage>cur.damage||(r.damage===cur.damage&&r.steps<cur.steps))arc.set(b,{...r,tpl:t});};
for(let i=0;i<20000;i++) add(randT());
while(ev<BUDGET){const k=[...arc.keys()];add(mut(arc.get(k[rnd(k.length)]).tpl));}
const sec=Number(process.hrtime.bigint()-t0)/1e9;

console.log(`MAP-Elites ${BUDGET.toLocaleString()}評価 / ${sec.toFixed(1)}秒 / アーカイブ ${arc.size}/${NC*NS}マス\n`);
console.log('■ 到達ステップ帯 × コスト → 達成できた最大ダメージ (30ステップ/秒 換算の飛行時間)');
const hdr=SPEED_BINS.map((b,i)=>{const lo=i?SPEED_BINS[i-1]+1:1;return `${(lo/30).toFixed(1)}-${(b/30).toFixed(1)}s`;});
console.log('cost | '+hdr.map(h=>h.padStart(11)).join(' | '));
for(let c=0;c<=MAX_COST;c++){
  const row=[];for(let s=0;s<NS;s++){const v=arc.get(c*NS+s);row.push(v?String(v.damage).padStart(11):'          -');}
  console.log(String(c).padStart(4)+' | '+row.join(' | '));
}
console.log('\n■ 各コストで「全量到達(ダメージ=コスト)」を達成できた最速の飛行');
for(let c=1;c<=MAX_COST;c++){
  let best=null;for(let s=0;s<NS;s++){const v=arc.get(c*NS+s);if(v&&v.damage===c&&(!best||v.steps<best.steps))best=v;}
  console.log(`  cost ${String(c).padStart(2)}: ${best?`${String(best.steps).padStart(4)}ステップ (${(best.steps/30).toFixed(1)}秒)`:'未達成'}`);
}
