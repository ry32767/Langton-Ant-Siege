// 改訂ルール v3: 「回収して運ぶ」方式
// アリが自陣の【配置した黒マス】を踏むと、そのマスを回収(白に戻す)して積載+1。
// 敵陣到達時、積載量がそのままダメージ。アリ自身の軌跡は積載にならない(踏み直しでの水増し不可)。
// → 黒マスはアリの進路を強く曲げる(黒=左折)ので、多く回収するほど制御が難しい = 自然なトレードオフ
export const W=40,H=20,BOUND=20,BUFFER=3,MAXX=BOUND-BUFFER;
export const DIRS=[[0,-1],[1,0],[0,1],[-1,0]];
const idx=(x,y)=>y*W+x;
export function evaluate(tpl,maxSteps=3000){
  const b=new Uint8Array(W*H), own=new Uint8Array(W*H);
  for(const [x,y] of tpl.cells){ b[idx(x,y)]=1; own[idx(x,y)]=1; }
  let x=tpl.ant[0],y=tpl.ant[1],dir=tpl.ant[2],steps=0,load=0;
  while(steps<maxSteps){
    const i=idx(x,y);
    if(b[i]===0){ b[i]=1; dir=(dir+1)&3; }
    else { b[i]=0; dir=(dir+3)&3; if(own[i]){ load++; own[i]=0; } }
    x+=DIRS[dir][0]; y=(y+DIRS[dir][1]+H)%H; steps++;
    if(x<0) return {outcome:'offboard',steps,damage:0,cost:tpl.cells.length};
    if(x>=BOUND) return {outcome:'arrived',steps,damage:load,cost:tpl.cells.length};
  }
  return {outcome:'timeout',steps,damage:0,cost:tpl.cells.length};
}
