// 対戦シミュレータ + 自己対戦による戦略AI学習の所要時間実測
import { W,H,BOUND,MAXX,DIRS,evaluate } from './engine4.mjs';
const rnd=n=>Math.floor(Math.random()*n);
const MAX_COST=20;

// --- テンプレート集を用意(MAP-Elites簡易版) ---
function randT(){const n=rnd(MAX_COST+1);const s=new Set();let x=rnd(MAXX),y=rnd(H),g=0;
  while(s.size<n&&g++<n*40){s.add(y*W+x);const d=DIRS[rnd(4)];const nx=x+d[0],ny=(y+d[1]+H)%H;if(nx>=0&&nx<MAXX){x=nx;y=ny;}}
  return {cells:[...s].map(i=>[i%W,Math.floor(i/W)]),ant:[rnd(MAXX),rnd(H),rnd(4)]};}
function mut(t){const c=t.cells.map(a=>[a[0],a[1]]);let ant=[...t.ant];const op=rnd(6);
  if(op===0&&c.length<MAX_COST)c.push([rnd(MAXX),rnd(H)]);
  else if(op===1&&c.length)c.splice(rnd(c.length),1);
  else if(op===2&&c.length){const k=rnd(c.length);const d=DIRS[rnd(4)];const nx=c[k][0]+d[0];if(nx>=0&&nx<MAXX)c[k]=[nx,(c[k][1]+d[1]+H)%H];}
  else if(op===3){ant[0]=rnd(MAXX);ant[1]=rnd(H);}
  else if(op===4){ant[2]=rnd(4);}
  else if(c.length){const dx=rnd(3)-1,dy=rnd(3)-1;for(let k=0;k<c.length;k++){const nx=c[k][0]+dx;if(nx>=0&&nx<MAXX)c[k]=[nx,(c[k][1]+dy+H)%H];}}
  const sn=new Set(),u=[];for(const a of c){const k=a[1]*W+a[0];if(!sn.has(k)){sn.add(k);u.push(a);}}
  return {cells:u,ant};}

console.log('--- Step1: テンプレート集の生成 ---');
let t0=process.hrtime.bigint();
const SPEED=[40,60,90,140,3000];
const arc=new Map(); let ev=0;
const add=t=>{const r=evaluate(t,3000);ev++;if(r.outcome!=='arrived'||r.damage===0)return;
  let s=0;while(s<SPEED.length-1&&r.steps>SPEED[s])s++;
  const b=r.damage*SPEED.length+s;const c=arc.get(b);
  if(!c||r.steps<c.steps)arc.set(b,{...r,tpl:t});};
for(let i=0;i<20000;i++)add(randT());
while(ev<2e6){const k=[...arc.keys()];add(mut(arc.get(k[rnd(k.length)]).tpl));}
const TEMPLATES=[...arc.values()].map(v=>({cost:v.cost,damage:v.damage,steps:v.steps}));
console.log(`  ${ev.toLocaleString()}評価 / ${(Number(process.hrtime.bigint()-t0)/1e9).toFixed(1)}秒 → テンプレート ${TEMPLATES.length}件`);

// --- 対戦シミュレータ(抽象化: テンプレートの damage/steps を使う) ---
// 方策パラメータ: [貯めるトークン閾値, ダメージ重み, 時間重み]
const HP0=100, TOKEN_CAP=20, SPS=30, TIME_LIMIT=180;
function pick(p, tokens){
  let best=null,bs=-1e9;
  for(const t of TEMPLATES){ if(t.cost>tokens) continue;
    const u=p[1]*t.damage - p[2]*(t.steps/SPS) - 0.0*t.cost;
    if(u>bs){bs=u;best=t;} }
  return best;
}
function match(pA,pB){
  const S=[{hp:HP0,tok:0,p:pA,fly:null},{hp:HP0,tok:0,p:pB,fly:null}];
  for(let tick=0; tick<TIME_LIMIT*10; tick++){       // 0.1秒刻み
    if(tick%10===0) for(const s of S) s.tok=Math.min(TOKEN_CAP,s.tok+1);
    for(let i=0;i<2;i++){
      const s=S[i], o=S[1-i];
      if(s.fly){ s.fly.t-=0.1; if(s.fly.t<=0){ o.hp-=s.fly.dmg; s.fly=null; } }
      else if(s.tok>=s.p[0]){
        const t=pick(s.p,s.tok);
        if(t){ s.tok-=t.cost; s.fly={t:t.steps/SPS, dmg:t.damage}; }
      }
    }
    if(S[0].hp<=0||S[1].hp<=0) return S[0].hp>S[1].hp?0:(S[1].hp>S[0].hp?1:-1);
  }
  return S[0].hp>S[1].hp?0:(S[1].hp>S[0].hp?1:-1);
}

console.log('\n--- Step2: 対戦シミュレーションのスループット ---');
t0=process.hrtime.bigint();
const NM=20000; let d=0;
for(let i=0;i<NM;i++){ const r=match([rnd(21),Math.random(),Math.random()],[rnd(21),Math.random(),Math.random()]); if(r<0)d++; }
let ms=Number(process.hrtime.bigint()-t0)/1e6;
console.log(`  ${NM.toLocaleString()}試合を ${ms.toFixed(0)}ms → ${(NM/ms*1000).toFixed(0)} 試合/秒 (引き分け ${(d/NM*100).toFixed(1)}%)`);

console.log('\n--- Step3: 自己対戦で方策を学習(CEM法) ---');
t0=process.hrtime.bigint();
let mu=[10,1,1], sig=[8,1,1];
const POP=60, ELITE=12, GEN=40, GAMES=40;
let totalMatches=0;
for(let g=0;g<GEN;g++){
  const pop=Array.from({length:POP},()=>mu.map((m,i)=>Math.max(0,m+sig[i]*(Math.random()*2-1)*1.7)));
  const score=pop.map(p=>{let w=0;
    for(let k=0;k<GAMES;k++){const opp=pop[rnd(POP)];const r=match(p,opp);totalMatches++;if(r===0)w++;else if(r<0)w+=0.5;}
    return w;});
  const order=[...pop.keys()].sort((a,b)=>score[b]-score[a]).slice(0,ELITE);
  for(let i=0;i<3;i++){
    const vals=order.map(k=>pop[k][i]);
    mu[i]=vals.reduce((a,b)=>a+b,0)/ELITE;
    sig[i]=Math.sqrt(vals.reduce((a,b)=>a+(b-mu[i])**2,0)/ELITE)+0.02;
  }
  if(g%10===9) console.log(`  世代${String(g+1).padStart(2)}: 方策=[閾値${mu[0].toFixed(1)}, ダメージ重み${mu[1].toFixed(2)}, 時間重み${mu[2].toFixed(2)}]`);
}
ms=Number(process.hrtime.bigint()-t0)/1e6;
console.log(`  ${GEN}世代 / ${totalMatches.toLocaleString()}試合 を ${(ms/1000).toFixed(1)}秒`);

// 学習済み vs ランダム方策
let w=0,n=4000;
for(let i=0;i<n;i++){ const r=match(mu,[rnd(21),Math.random(),Math.random()]); if(r===0)w++; }
console.log(`\n  学習済み方策 vs ランダム方策: 勝率 ${(w/n*100).toFixed(1)}% (${n}試合)`);
