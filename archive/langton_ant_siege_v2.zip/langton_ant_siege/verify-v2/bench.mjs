// テンプレート生成の所要時間ベンチマーク
import { W,H,BOUND,BUFFER,MAXX, evaluate } from './engine2.mjs';

const rnd = n => Math.floor(Math.random()*n);

function randomTemplate(maxCost){
  const n = rnd(maxCost+1);
  const set = new Set();
  // 連結した塊にする(ランダムウォーク)
  let x = rnd(MAXX), y = rnd(H), guard = 0;
  while (set.size < n && guard++ < n*40){
    set.add(y*W+x);
    const d = [[0,-1],[1,0],[0,1],[-1,0]][rnd(4)];
    const nx = x+d[0], ny = (y+d[1]+H)%H;
    if (nx>=0 && nx<MAXX){ x=nx; y=ny; }
  }
  const cells = [...set].map(i => [i%W, Math.floor(i/W)]);
  return { cells, ant: [rnd(MAXX), rnd(H), rnd(4)] };
}

// --- 1. 単純スループット計測 ---
console.log('=== 1. 評価スループット(1回の評価 = 1回のシミュレーション) ===');
for (const maxSteps of [1000, 3000, 10000]){
  const N = 50000;
  const tpls = Array.from({length:N}, () => randomTemplate(20));
  const t0 = process.hrtime.bigint();
  let arr=0, off=0, to=0, sumSteps=0;
  for (const t of tpls){
    const r = evaluate(t, maxSteps);
    sumSteps += r.steps;
    if (r.outcome==='arrived') arr++; else if (r.outcome==='offboard') off++; else to++;
  }
  const ms = Number(process.hrtime.bigint()-t0)/1e6;
  console.log(` maxSteps=${String(maxSteps).padStart(5)}: ${N}評価を ${ms.toFixed(0)}ms → ${(N/ms*1000).toFixed(0)} 評価/秒 | 到達${(arr/N*100).toFixed(1)}% 場外${(off/N*100).toFixed(1)}% 打切り${(to/N*100).toFixed(1)}% 平均${(sumSteps/N).toFixed(0)}ステップ`);
}
