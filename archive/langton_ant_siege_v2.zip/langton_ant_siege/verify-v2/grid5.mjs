import { W,H,MAXX,DIRS,ANT_COST,evaluate } from './engine5.mjs';
const rnd=n=>Math.floor(Math.random()*n);
const MAX_CELLS=20;                       // 黒マスは最大20個 → コストは 5..25
const SPS=Number(process.env.SPS||60);    // ステップ/秒
const SPEED=[1,2,4,8,16,32,1e9].map(s=>s*SPS);   // 秒単位のtier
const NS=SPEED.length;
const st=s=>{for(let i=0;i<NS;i++) if(s<=SPEED[i]) return i; return NS-1;};
function randT(){const n=rnd(MAX_CELLS+1);const s=new Set();let x=rnd(MAXX),y=rnd(H),g=0;
  while(s.size<n&&g++<n*40){s.add(y*W+x);const d=DIRS[rnd(4)];const nx=x+d[0],ny=(y+d[1]+H)%H;if(nx>=0&&nx<MAXX){x=nx;y=ny;}}
  return {cells:[...s].map(i=>[i%W,Math.floor(i/W)]),ant:[rnd(MAXX),rnd(H),rnd(4)]};}
function mut(t){const c=t.cells.map(a=>[a[0],a[1]]);let ant=[...t.ant];const op=rnd(6);
  if(op===0&&c.length<MAX_CELLS)c.push([rnd(MAXX),rnd(H)]);
  else if(op===1&&c.length)c.splice(rnd(c.length),1);
  else if(op===2&&c.length){const k=rnd(c.length);const d=DIRS[rnd(4)];const nx=c[k][0]+d[0];if(nx>=0&&nx<MAXX)c[k]=[nx,(c[k][1]+d[1]+H)%H];}
  else if(op===3){ant[0]=rnd(MAXX);ant[1]=rnd(H);}
  else if(op===4){ant[2]=rnd(4);}
  else if(c.length){const dx=rnd(3)-1,dy=rnd(3)-1;for(let k=0;k<c.length;k++){const nx=c[k][0]+dx;if(nx>=0&&nx<MAXX)c[k]=[nx,(c[k][1]+dy+H)%H];}}
  const sn=new Set(),u=[];for(const a of c){const k=a[1]*W+a[0];if(!sn.has(k)){sn.add(k);u.push(a);}}
  return {cells:u,ant};}
const BUDGET=Number(process.argv[2]||5e6);
const arc=new Map(); let ev=0; const t0=process.hrtime.bigint();
const add=t=>{const r=evaluate(t,3000);ev++;if(r.outcome!=='arrived')return;
  const b=r.cost*NS+st(r.steps);const c=arc.get(b);
  if(!c||r.damage>c.damage)arc.set(b,{...r,tpl:t});};
for(let i=0;i<20000;i++)add(randT());
while(ev<BUDGET){const k=[...arc.keys()];add(mut(arc.get(k[rnd(k.length)]).tpl));}
console.log(`MAP-Elites ${BUDGET.toLocaleString()}評価 / ${(Number(process.hrtime.bigint()-t0)/1e9).toFixed(1)}秒 / ${arc.size}マス (SPS=${SPS})\n`);
console.log('■ コスト(=アリ5+黒マス数) × 到達時間帯 → 最大ダメージ');
console.log('cost |'+['~1s','~2s','~4s','~8s','~16s','~32s','32s~'].map(h=>h.padStart(7)).join(' |'));
for(let c=ANT_COST;c<=ANT_COST+MAX_CELLS;c++){
  const row=[];for(let s=0;s<NS;s++){const v=arc.get(c*NS+s);row.push(v?String(v.damage).padStart(7):'      -');}
  console.log(String(c).padStart(4)+' |'+row.join(' |'));
}
