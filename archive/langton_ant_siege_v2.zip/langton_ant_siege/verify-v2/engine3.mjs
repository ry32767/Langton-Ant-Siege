// 改訂ルール v2: ダメージ = 到達マスから連結する黒マスのうち「プレイヤーが配置したマス」の数
// アリの軌跡は「導線(橋)」として連結には寄与するが、ダメージそのものにはならない。
// → 投資が最大1:1でダメージに変換され、コスト0のタダ乗りが消える。
export const W=40, H=20, BOUND=20, BUFFER=3, MAXX=BOUND-BUFFER;
export const DIRS=[[0,-1],[1,0],[0,1],[-1,0]];
const idx=(x,y)=>y*W+x;

export function evaluate(tpl, maxSteps=3000){
  const board=new Uint8Array(W*H);
  const owned=new Uint8Array(W*H);   // 1 = プレイヤーが配置したマス
  for(const [x,y] of tpl.cells){ board[idx(x,y)]=1; owned[idx(x,y)]=1; }

  let x=tpl.ant[0], y=tpl.ant[1], dir=tpl.ant[2], steps=0;
  while(steps<maxSteps){
    const i=idx(x,y);
    if(board[i]===0){ board[i]=1; dir=(dir+1)&3; }
    else            { board[i]=0; dir=(dir+3)&3; }
    owned[i]=0;                       // アリが触れたマスは以後アリ由来
    x+=DIRS[dir][0];
    y=(y+DIRS[dir][1]+H)%H;
    steps++;
    if(x<0) return {outcome:'offboard', steps, damage:0, cost:tpl.cells.length};
    if(x>=BOUND){
      board[idx(x,y)]=1;
      // 連結成分を求め、そのうち owned のものだけ数える
      const seen=new Uint8Array(W*H); const st=[[x,y]]; seen[idx(x,y)]=1; let dmg=0;
      while(st.length){
        const [cx,cy]=st.pop();
        if(owned[idx(cx,cy)]) dmg++;
        for(const [dx,dy] of DIRS){
          const nx=cx+dx; if(nx<0||nx>=W) continue;
          const ny=(cy+dy+H)%H; const j=idx(nx,ny);
          if(!seen[j] && board[j]===1){ seen[j]=1; st.push([nx,ny]); }
        }
      }
      return {outcome:'arrived', steps, damage:dmg, cost:tpl.cells.length};
    }
  }
  return {outcome:'timeout', steps, damage:0, cost:tpl.cells.length};
}
