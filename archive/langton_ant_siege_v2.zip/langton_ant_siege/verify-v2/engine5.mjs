// 最終ルール v4 (ユーザー選択: 連結黒マス総数=アリの軌跡も加算)
// - ダメージ = 到達マスから4連結する黒マスの総数(配置マス + アリの軌跡)
// - アリ本体に基礎コスト ANT_COST を課す(コスト0のタダ乗りを封じる)
// - 数えた黒マスはすべて白に戻す(消費 = 盤面の掃除・再利用不可)
// - 境界から BUFFER 列は配置禁止 / 上下ラップ
export const W=40,H=20,BOUND=20,BUFFER=3,MAXX=BOUND-BUFFER;
export const ANT_COST=5;
export const DIRS=[[0,-1],[1,0],[0,1],[-1,0]];
const idx=(x,y)=>y*W+x;
export function evaluate(tpl,maxSteps=3000){
  const b=new Uint8Array(W*H);
  for(const [x,y] of tpl.cells) b[idx(x,y)]=1;
  let x=tpl.ant[0],y=tpl.ant[1],dir=tpl.ant[2],steps=0;
  const cost=ANT_COST+tpl.cells.length;
  while(steps<maxSteps){
    const i=idx(x,y);
    if(b[i]===0){b[i]=1;dir=(dir+1)&3;} else {b[i]=0;dir=(dir+3)&3;}
    x+=DIRS[dir][0]; y=(y+DIRS[dir][1]+H)%H; steps++;
    if(x<0) return {outcome:'offboard',steps,damage:0,cost};
    if(x>=BOUND){
      b[idx(x,y)]=1;
      const seen=new Uint8Array(W*H); const st=[[x,y]]; seen[idx(x,y)]=1; let n=0;
      while(st.length){const [cx,cy]=st.pop(); n++;
        for(const [dx,dy] of DIRS){const nx=cx+dx; if(nx<0||nx>=W)continue;
          const ny=(cy+dy+H)%H; const j=idx(nx,ny);
          if(!seen[j]&&b[j]===1){seen[j]=1;st.push([nx,ny]);}}}
      return {outcome:'arrived',steps,damage:n,cost};
    }
  }
  return {outcome:'timeout',steps,damage:0,cost};
}
