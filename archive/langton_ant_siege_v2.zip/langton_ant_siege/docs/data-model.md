# データモデル

背景は [../README.md](../README.md)、機能・受け入れ条件は [spec.md](spec.md)、全体構成は [architecture.md](architecture.md)。

```mermaid
erDiagram
    MATCH ||--|| BOARD : uses
    MATCH ||--o{ SIDE : has
    SIDE ||--o| ANT : "flying(0..1)"
    SIDE ||--o{ PLACEDCELL : placed
    TEMPLATE ||--o{ TEMPLATECELL : contains
    MATCH {
        int stepsPerSecond "既定60"
        int timeLimitSec "既定180"
        int elapsedStep
        string phase "playing または finished"
        string result "side1 / side2 / draw / null"
        int seed "試合開始時に決める擬似乱数シード"
    }
    BOARD {
        int width "40"
        int height "20"
        int boundaryX "20"
        int placementMaxX "16(x=17..19は配置禁止)"
        bool wrapVertical "true(上下ラップ)"
    }
    SIDE {
        string id "side1 または side2"
        string controller "human または cpu"
        bool mirrored "side2 は true"
        int hp
        int tokens
        int tokenCap "既定25"
    }
    ANT {
        string sideId FK
        int x
        int y
        int direction "0=up 1=right 2=down 3=left"
        int stepsFlown
        string flippedCells "このアリが反転させたマスの集合"
    }
    PLACEDCELL {
        string sideId FK
        int x
        int y
    }
    TEMPLATE {
        string id
        int cost "5 + cells.length"
        int arrivalStep
        int expectedDamage
        int costTier
        int speedTier
    }
    TEMPLATECELL {
        string templateId FK
        int x
        int y
    }
```

| エンティティ | 主なフィールド | 補足 |
|---|---|---|
| Match(試合) | `stepsPerSecond`, `timeLimitSec`, `elapsedStep`, `phase`, `result`, `seed` | 180秒経過で残HP比較。同数なら `draw`。`seed` は再現用([spec.md](spec.md) の「乱数とシード」) |
| Board(盤面) | `width`, `height`, `boundaryX`, `placementMaxX`, `wrapVertical` | 1枚を両陣営で共有。値は side1 ローカル座標での定義で、side2 は `mirrored` で反転して使う |
| Side(陣営) | `id`, `controller`, `mirrored`, `hp`, `tokens`, `tokenCap` | `tokens` は1秒ごとに+1、`tokenCap` で頭打ち(既定25)。アリ飛行中も蓄積。`controller` で人/CPUを切り替える |
| Ant(アリ) | `sideId`, `x`, `y`, `direction`, `stepsFlown`, `flippedCells` | 1陣営につき最大1匹。到達 or 場外で消滅。`flippedCells` はクリーンアップに使う |
| PlacedCell(配置マス) | `sideId`, `x`, `y` | 発射時に置かれた黒マス。アリ消滅時にこの陣営の分をまとめて白に戻す。相手のクリーンアップからは除外される |
| Template(テンプレート) | `id`, `cost`, `arrivalStep`, `expectedDamage`, `costTier`, `speedTier` | `scripts/generate-templates.mjs` が生成。プレイヤーの一覧表示とCPUの選択の両方で使う |
| TemplateCell | `templateId`, `x`, `y` | テンプレートの黒マス座標。アリの初期位置・向きは Template に `antX` / `antY` / `antDir` として持つ |

## 盤面の内部表現

セルは独立したエンティティにせず、`Uint8Array(width * height)` の 0/1(白/黒)で持つ。40×20=800セルなのでコピーも探索も安価。

配置マスは `Side.placedCells`(座標のSet)で、アリが反転させたマスは `Ant.flippedCells`(座標のSet)で持つ。アリ消滅時のクリーンアップは `placedCells ∪ flippedCells` を白に戻すだけ([spec.md](spec.md) の「盤面のクリーンアップ」)。

両陣営のアリは自陣の中だけを移動するため、これらの集合が陣営をまたいで重なることはない。所有者の追跡は不要。

> v1 にあった `Cell.lastFlippedByAntId`(マス単位で最後に反転させたアリを追跡)は廃止した。アリ側が自分の反転集合を持つ方が、クリーンアップが集合演算1回で書けて安い。

## 座標系

盤面は1枚の `Uint8Array` だが、エンジンは **side1 のローカル座標**で動く。side2 のアクセスは `xGlobal = 39 - xLocal`、向きは left⇄right を入れ替える([spec.md](spec.md) の「陣営の座標系」)。`Side.mirrored`(boolean)でどちらかを保持する。

## data/templates.json

```json
{
  "generatedAt": "2026-08-06T00:00:00Z",
  "config": { "width": 40, "height": 20, "boundaryX": 20, "placementMaxX": 16, "antCost": 5, "maxCells": 20 },
  "templates": [
    {
      "id": "c08s03",
      "cells": [[12, 5], [12, 6], [13, 6]],
      "antX": 11, "antY": 7, "antDir": 1,
      "cost": 8,
      "arrivalStep": 240,
      "expectedDamage": 65,
      "costTier": 8,
      "speedTier": 3
    }
  ]
}
```

座標・向きはすべて **side1 ローカル座標**。side2 が使うときにミラーリング変換をかける([spec.md](spec.md) の「陣営の座標系」)。

`costTier` は cost の値そのもの(5..25 の21段階)。`speedTier` は到達ステップ数のビンで、境界は以下(60ステップ/秒換算)。

| speedTier | 到達ステップ | 秒 |
|---|---|---|
| 0 | 1..60 | 〜1.0s |
| 1 | 61..120 | 〜2.0s |
| 2 | 121..240 | 〜4.0s |
| 3 | 241..480 | 〜8.0s |
| 4 | 481..960 | 〜16.0s |
| 5 | 961..1920 | 〜32.0s |
| 6 | 1921以上 | 32.0s〜 |

`id` は `c{cost:02d}s{speedTier}` 形式(例 `c08s03`)。1ビンにつき最良の1件だけを保存するため一意になる。

> [spec.md](spec.md) の未決定事項のとおり、既定では **speedTier 0〜3(到達8秒以内)のみを一覧に出す**方針。tier 4〜6 は生成はするが採用しない。

## data/policy.json

```json
{
  "trainedAt": "2026-08-06T00:00:00Z",
  "method": "CEM",
  "generations": 40,
  "matches": 96000,
  "winRateVsRandom": 0.908,
  "policy": { "fireThreshold": 8, "wDamage": 1.94, "wTime": 0.32 }
}
```

> ⚠️ 上の値は**形式を示す例**であり、実在の学習結果ではない。[REVIEW.md](../REVIEW.md) 付録B-4 の実測値(閾値4.4)は基礎コスト導入前の条件で得たもので、最終ルールでは使えない。`node scripts/train-policy.mjs` を実行して実際の値で上書きすること(所要数秒)。

| フィールド | 意味 |
|---|---|
| `fireThreshold` | このトークン数以上でのみ発射を検討する |
| `wDamage` / `wTime` | `Utility = wDamage × expectedDamage - wTime × (arrivalStep / stepsPerSecond)` |
| `winRateVsRandom` | 学習の効果を示す記録値。再学習したら更新する |

> `data/*.json` は手で編集しない。ロジックを直したら `scripts/generate-templates.mjs` / `scripts/train-policy.mjs` を再実行する([../AGENTS.md](../AGENTS.md) の Do NOT)。
